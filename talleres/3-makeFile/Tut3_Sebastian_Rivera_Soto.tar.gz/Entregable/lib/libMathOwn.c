#include <math.h>

float sumar(float a, float b) {
  return a + b;
}

float restar(float a, float b){
  return a - b;
}

float multiplicar(float a, float b){
  return a * b;
}

float dividir(float a, float b){
  return a / b;
}

float raizCuadrada(float a){
  return sqrt(a);
}
