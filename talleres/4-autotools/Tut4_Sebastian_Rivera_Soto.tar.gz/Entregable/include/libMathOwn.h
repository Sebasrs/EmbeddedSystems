#ifndef _BIBLIOTECA_H
#define _BIBLIOTECA_H

float sumar(float a, float b);
float restar(float a, float b);
float multiplicar(float a, float b);
float dividir(float a, float b);
float raizCuadrada(float a);

#endif