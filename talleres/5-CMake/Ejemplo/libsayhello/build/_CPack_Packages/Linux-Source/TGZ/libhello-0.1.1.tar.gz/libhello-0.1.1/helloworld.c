#include <say.h>
int main(int argc, char const *argv[])
{
say_hello();
return 0;
}
