#include <stdio.h>
void say_hello(void);
